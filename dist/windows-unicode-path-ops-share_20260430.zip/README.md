# Windows Unicode Path Ops

Portable, public-share version of a Codex skill plus helper scripts for reducing Windows path failures with non-ASCII characters.

This package focuses on a common failure mode on Windows PowerShell 5.1:

- UTF-8 files are displayed as mojibake when decoded as GBK or CP936
- inline native pipes such as `@' ... '@ | python -` can corrupt non-ASCII paths into `??`
- Python or other native programs then fail with `OSError: [Errno 22] Invalid argument`

The repository is structured for direct GitHub upload and contains:

- a reusable Codex skill
- PowerShell and Python helper scripts
- a small Windows-focused test harness
- de-identified metrics and plots

## Repository Layout

- `skill/`
  A shareable skill bundle with `SKILL.md`, references, and helper scripts.
- `tests/`
  Small runtime tests that create temporary non-ASCII paths and verify safe versus unsafe execution patterns.
- `metrics/`
  De-identified numeric summaries from local investigation and test results.
- `figures/`
  PNG charts rendered from the metrics CSV files.
- `scripts/`
  Repository-level support scripts such as metric visualization.
- `dist/`
  Final zip archive for upload or sharing.

## What Problem This Solves

Two distinct failure classes are common:

1. Display-layer corruption
- A UTF-8 file is decoded with the wrong code page.
- The path may still be valid.

2. Execution-layer corruption
- A PowerShell pipe or native boundary converts a non-ASCII path into `??`.
- The path is no longer valid and native file access fails.

This package primarily reduces the second class and makes the first class easier to diagnose.

## Included Helpers

- `skill/scripts/invoke_python_utf8_safe.ps1`
  Launch a real Python script with UTF-8 console settings instead of piping source text to Python.

- `skill/scripts/read_utf8_text.ps1`
  Read UTF-8 files explicitly from PowerShell 5.1.

- `skill/scripts/write_json_utf8.py`
  Write JSON with explicit UTF-8 encoding.

- `skill/scripts/write_utf8_nobom_text.ps1`
  Write UTF-8 text without a BOM from PowerShell.

## Recommended Usage

Avoid:

```powershell
@'
from pathlib import Path
Path(r'E:\demo\项目A\data.txt').read_text(encoding='utf-8')
'@ | python -
```

Prefer:

```powershell
powershell -ExecutionPolicy Bypass -File .\skill\scripts\invoke_python_utf8_safe.ps1 `
  -PythonExe E:\conda\envs_dirs\ezs_env\python.exe `
  -ScriptPath .\tests\scripts\echo_path_roundtrip.py `
  E:\demo\项目A\data.txt `
  E:\demo\项目A\result.json
```

## Running Tests

From PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File .\tests\run_tests.ps1
```

Outputs:

- `tests/artifacts/test_results.csv`
- `tests/artifacts/test_summary.json`
- runtime files in `tests/artifacts/runtime/`

## Rendering Metrics

```powershell
python .\scripts\render_metrics.py
```

Outputs:

- `figures/incident_counts.png`
- `figures/test_outcomes.png`

## Notes

- This package is intentionally de-identified.
- No user-specific directories, account names, or institution names are included.
- The tests create generic non-ASCII directories at runtime instead of storing sensitive paths in the repository.
